const app = getApp();
const db = wx.cloud.database()
const cateItems = db.collection('cateItems')

Page({
  data: {
    cate_list: []
  },

  onLoad: function(options) {
    var _this = this
    db.collection('cateItems').get({
      success: res => {
        // console.log(res)
        this.setData({
          cate_list: res.data
        })
      }
    })
  },

  toDetail: function(e) {
    let cateIndex = e.currentTarget.dataset.cateIndex;
    wx.navigateTo({
      url: '/pages/detail/detail?cateIndex=' + cateIndex
    })
  },
  toAddCate: function (e) {
    wx.navigateTo({
      url: '/pages/addCate/addCate'
    })
  },
  changeData: function() {
    this.onLoad();
  }
})