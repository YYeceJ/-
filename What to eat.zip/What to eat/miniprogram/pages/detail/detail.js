const app = getApp();
const db = wx.cloud.database()
const cateItems = db.collection('cateItems')
import Dialog from '../../dist/dialog/dialog';

Page({
  data: {
    cate: {}
  },
  onLoad: function(options) {
    const index = options.cateIndex
    const _this = this
    db.collection('cateItems').get({
      success: res => {
        this.setData({
          cate: res.data[index]
        })
      }
    })
  },

  updateCate(e) {
    let cate = JSON.stringify(e.currentTarget.dataset.cate)
    wx.navigateTo({
      url: '/pages/updateCate/updateCate?cate=' + cate
    })
  },

  deleteCate(e) {
    Dialog.confirm({
      title: '提示',
      message: '确定要删除吗'
    }).then(() => {
      const _this = this
      const id = e.currentTarget.dataset.id
      db.collection('cateItems').doc(id).remove({
        success: res => {
          wx.showToast({
            title: '删除成功',
            icon: 'success',
            duration: 2000
          })
          this.changeParentData()
        }
      })
    }).catch(() => {});
  },
  
  changeData: function () {
    this.onLoad();
  },

  changeParentData: function() {
    var pages = getCurrentPages(); //当前页面栈
    if (pages.length > 1) {
      var beforePage = pages[pages.length - 2]; //获取上一个页面实例对象
      beforePage.changeData(); //触发父页面中的方法
      wx.navigateBack({
        delta: 1         // 返回上一页
      });
    }
  }

})