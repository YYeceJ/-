Page({
  data: {
    nickName: "",
    avatarUrl: ""
  },
  onLoad: function(options) {
    console.log(options)
    var that = this
    wx.getUserInfo({
      success: function(res) {
        that.setData({
          nickName: res.userInfo.nickName,
          avatarUrl: res.userInfo.avatarUrl,
        })
      },
    })
  },
  toAbout: function (e) {
    wx.navigateTo({
      url: '/pages/about/about' 
    })
  },
})