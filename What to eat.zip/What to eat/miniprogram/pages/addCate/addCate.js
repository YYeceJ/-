import Dialog from '../../dist/dialog/dialog';

const app = getApp();
const db = wx.cloud.database()
const cateItems = db.collection('cateItems')

Page({
  data: {
    imgList: [],
  },
  onLoad: function(options) {
  },

  ChooseImage() {
    wx.chooseImage({
      count: 4,
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album'], //从相册选择
      success: (res) => {
        if (this.data.imgList.length != 0) {
          this.setData({
            imgList: this.data.imgList.concat(res.tempFilePaths)
          })
        } else {
          this.setData({
            imgList: res.tempFilePaths
          })
        }
      }
    });
  },
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList[0],
      current: e.currentTarget.dataset.url
    });
  },
  DelImg(e) {
    Dialog.confirm({
      title: '提示',
      message: '确定要删除吗'
    }).then(() => {
      // on confirm
      this.data.imgList.splice(e.currentTarget.dataset.index, 1);
      this.setData({
        imgList: this.data.imgList
      })
    }).catch(() => {});
  },

  formSubmit(e) {
    var _this = this;
    var values = e.detail.value

    if (values.cate_name == "") {
      Dialog.alert({
        title: '提示',
        message: '请输入菜品名称'
      })
    } else if (values.cate_name == "") {
      Dialog.alert({
        title: '提示',
        message: '请输入菜品名称'
      })
    } else if (values.price == "") {
      Dialog.alert({
        title: '提示',
        message: '请输入菜品价格'
      })
    } 
    // else if (this.data.imgList[0] == undefined) {
    //   imageUrl = ".././images/cai.jpg"
    // } 
    else {
      db.collection('cateItems').add({
        data: {
          cate_name: values.cate_name,
          image: this.data.imgList,
          price: values.price,
          remark: values.remark,
        },
        success: res => {
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 2000
          })
          this.changeParentData()
        }
      })
    }
  },

  changeParentData: function() {
    var pages = getCurrentPages(); //当前页面栈
    if (pages.length > 1) {
      var beforePage = pages[pages.length - 2]; //获取上一个页面实例对象
      beforePage.changeData(); //触发父页面中的方法
    }
    wx.navigateBack({
      delta: 1 // 返回上一页
    });
  }
})