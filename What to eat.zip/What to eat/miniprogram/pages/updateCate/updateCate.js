import Dialog from '../../dist/dialog/dialog';

const app = getApp();
var db = wx.cloud.database()
var cateItems = db.collection('cateItems')

Page({
  data: {
    cate: {},
    imgList: []
  },

  onLoad: function(options) {
    let cate = JSON.parse(options.cate);
    this.setData({
      cate: cate,
    })
    this.setData({
      imgList: this.data.cate.image
    })
  },

  ChooseImage() {
    wx.chooseImage({
      count: 4,
      sizeType: ['original', 'compressed'],
      sourceType: ['album'],
      success: (res) => {
        if (this.data.imgList.length != 0) {
          this.setData({
            imgList: this.data.imgList.concat(res.tempFilePaths)
          })
        } else {
          this.setData({
            imgList: res.tempFilePaths
          })
        }
      }
    });
  },

  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },

  DelImg(e) {
    Dialog.confirm({
      title: '提示',
      message: '确定要删除吗'
    }).then(() => {
      // on confirm
      this.data.imgList.splice(e.currentTarget.dataset.index, 1);
      this.setData({
        imgList: this.data.imgList
      })
    }).catch(() => {});
  },

  formSubmit(e) {
    const _this = this;
    const values = e.detail.value
    const id = this.data.cate._id

    db.collection('cateItems').doc(id).update({
      data: {
        cate_name: values.cate_name,
        image: this.data.imgList,
        price: values.price,
        remark: values.remark,
      },
      success: res => {
        success: res => {
        }
      },
      complete:res => {
        this.changeParentData()
      },
      fail: err => {
        icon: 'none',
        console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },

  changeParentData: function () {
    var pages = getCurrentPages(); //当前页面栈
    if (pages.length > 1) {
      var beforePage = pages[pages.length - 3]; //获取上一个页面实例对象
      beforePage.changeData(); //触发父页面中的方法
      wx.navigateBack({
        delta: 2        // 返回上一页
      });
    }
  }
})