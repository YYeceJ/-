const app = getApp();
const db = wx.cloud.database()
const cateItems = db.collection('cateItems')

Page({
  data: {
    cate_list: [],
    curCate:{},
    cardCur: 0,
    show: false,
    swiperList: [{
        id: 0,
        type: 'image',
      url: 'https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1628498222,3505106306&fm=58&bpow=800&bpoh=533'
      }, {
        id: 1,
        type: 'image',
        url: 'https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3281633379,3427775904&fm=58&bpow=750&bpoh=1000',
      }, {
        id: 2,
        type: 'image',
        url: 'https://ss0.baidu.com/73t1bjeh1BF3odCf/it/u=3801675662,3046372989&fm=85&s=D918669E42C16941643283750300506B'
      }, {
        id: 3,
        type: 'image',
        url: 'http://img2.imgtn.bdimg.com/it/u=903693143,1881824841&fm=26&gp=0.jpg'
      },
      {
        id: 4,
        type: 'image',
        url: 'https://ss3.baidu.com/-rVXeDTa2gU2pMbgoY3K/it/u=3251860000,559218401&fm=202&src=766&mola=new&crop=v1'
      }, {
        id: 5,
        type: 'image',
        url: 'https://paimgcdn.baidu.com/B0E7D31CCA616F67?src=http%3A%2F%2Fms.bdimg.com%2Fdsp-image%2F2287717996.jpg&rz=urar_2_968_600&v=0'
      }, {
        id: 6,
        type: 'image',
        url: 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=4138336383,3699222860&fm=27&gp=0.jpg'
      }
    ],
  },
  onLoad() {
    this.towerSwiper('swiperList');

    var _this = this
    db.collection('cateItems').get({
      success: res => {
        // console.log(res)
        this.setData({
          cate_list: res.data
        })
      }
    })
  },
  DotStyle(e) {
    this.setData({
      DotStyle: e.detail.value
    })
  },
  // cardSwiper
  cardSwiper(e) {
    this.setData({
      cardCur: e.detail.current
    })
  },
  // towerSwiper
  // 初始化towerSwiper
  towerSwiper(name) {
    let list = this.data[name];
    for (let i = 0; i < list.length; i++) {
      list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
      list[i].mLeft = i - parseInt(list.length / 2)
    }
    this.setData({
      swiperList: list
    })
  },
  // towerSwiper触摸开始
  towerStart(e) {
    this.setData({
      towerStart: e.touches[0].pageX
    })
  },
  // towerSwiper计算方向
  towerMove(e) {
    this.setData({
      direction: e.touches[0].pageX - this.data.towerStart > 0 ? 'right' : 'left'
    })
  },
  // towerSwiper计算滚动
  towerEnd(e) {
    let direction = this.data.direction;
    let list = this.data.swiperList;
    if (direction == 'right') {
      let mLeft = list[0].mLeft;
      let zIndex = list[0].zIndex;
      for (let i = 1; i < list.length; i++) {
        list[i - 1].mLeft = list[i].mLeft
        list[i - 1].zIndex = list[i].zIndex
      }
      list[list.length - 1].mLeft = mLeft;
      list[list.length - 1].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    } else {
      let mLeft = list[list.length - 1].mLeft;
      let zIndex = list[list.length - 1].zIndex;
      for (let i = list.length - 1; i > 0; i--) {
        list[i].mLeft = list[i - 1].mLeft
        list[i].zIndex = list[i - 1].zIndex
      }
      list[0].mLeft = mLeft;
      list[0].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    }
  },

  order: function() {
    var that = this;
    const cate_list = this.data.cate_list
    const curCate = cate_list[Math.floor(Math.random() * cate_list.length)];

    that.setData({
      show: (!that.data.show)
    })
    that.setData({
      curCate : curCate
    })
  },
})