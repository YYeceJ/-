var cateItems = [
  {
    cate_name: '洁面皂',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '卸妆',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '洁面乳',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '洁面皂',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '卸妆',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '洁面乳',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '洁面皂',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '卸妆',
    price: "10.00",
    image: "../../images/cate.png"
  },
  {
    cate_name: '洁面乳',
    price: "10.00",
    image: "../../images/cate.png"
  },
  
  {
    cate_name: '面部祛角质',
    price: "10.00",
    image: "../../images/cate.png"
  }
]

module.exports = {
  cateItems: cateItems
}